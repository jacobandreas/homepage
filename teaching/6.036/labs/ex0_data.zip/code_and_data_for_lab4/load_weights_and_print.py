import json

weights = json.loads(open('tokenized_lr_weights.json').read())

def get_weights(WORDS):
	out = []
	for w in WORDS:
		if w in weights.keys():
			out.append((w, "%04f" % weights[w]))
		else:
			out.append((w, "not in set"))
	return out


def pretty_print(list_of_tuples):
    print('\n'.join(["%s\t\t%s" % t if len(t[0]) < 8 else "%s\t%s" % t for t in list_of_tuples]))


if __name__ == '__main__':
    WORDS = ["yummy", "indian", "mexican", "italian", "chinese", "european", "gross"]
    pretty_print(get_weights(WORDS))